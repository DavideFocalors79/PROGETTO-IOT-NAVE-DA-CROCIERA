import paho.mqtt.client as mqtt
import json
import cripta  # Modulo locale (nella stessa cartella iotp/)

# Carica configurazione IoTPlatform
with open('iotp/iotp.json', 'r') as f:
    config = json.load(f)

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print(f"Connesso al broker MQTT. In ascolto su topic: {config['topic']}")
        client.subscribe(config["topic"])
    else:
        print(f"Errore di connessione, codice: {rc}")

def on_message(client, userdata, msg):
    dato_criptato = msg.payload.decode('utf-8')

    # Decriptazione
    dato_json = cripta.decriptazione(dato_criptato)
    dato = json.loads(dato_json)

    # Debug: mostra dato non criptato ricevuto
    print(f"Ricevuto (decriptato): {json.dumps(dato, indent=2)}")

    # Archiviazione su dbplatform.json
    dbfile = config["dbfile"]
    with open(f"iotp/{dbfile['file']}", dbfile["modo"]) as f:
        f.write(json.dumps(dato) + "\n")

def main():
    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message

    client.connect(config["broker"]["host"], config["broker"]["porta"])
    client.loop_forever()  # Resta in ascolto finché non si interrompe con Ctrl+C

if __name__ == "__main__":
    main()
