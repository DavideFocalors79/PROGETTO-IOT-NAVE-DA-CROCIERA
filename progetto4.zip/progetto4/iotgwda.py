import socket
import json
import time
import paho.mqtt.client as mqtt
import cripta  # Modulo locale

# Carica parametri
with open('configurazione/parametri.json', 'r') as f:
    config = json.load(f)

def calcola_media(lista):
    return round(sum(lista) / len(lista), config["N_DECIMALI"])

def main():
    # --- Setup MQTT publisher ---
    client = mqtt.Client()
    client.connect(config["BROKER"], config["PORTA_BROKER"])
    client.loop_start()
    print(f"Connesso al broker MQTT: {config['BROKER']}")

    # --- Setup socket TCP per ricevere dati dal DC ---
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((config["IP_SERVER"], config["PORTA_SERVER"]))
    server.listen(1)
    print(f"DA in ascolto su {config['IP_SERVER']}:{config['PORTA_SERVER']}...")

    conn, addr = server.accept()
    print(f"DC connesso da {addr}")

    # Invia tempo rilevazione al DC
    conn.send(json.dumps({"TEMPO_RILEVAZIONE": config["TEMPO_RILEVAZIONE"]}).encode('utf-8'))

    rilevazioni_temp = []
    rilevazioni_umid = []
    invio_numero = 1

    try:
        while True:
            data = conn.recv(4096).decode('utf-8')
            if not data:
                break

            dato_dc = json.loads(data)
            obs = dato_dc["osservazione"]
            rilevazioni_temp.append(obs["temperatura"])
            rilevazioni_umid.append(obs["umidita"])

            # Ogni TEMPO_INVIO rilevazioni, calcola media e pubblica via MQTT
            if len(rilevazioni_temp) >= config["TEMPO_INVIO"]:
                print("Gateway IoT in ricezione e invio")

                payload_da = {
                    "cabina": dato_dc["camera"],
                    "ponte": dato_dc["ponte"],
                    "temperaturam": calcola_media(rilevazioni_temp),
                    "umiditam": calcola_media(rilevazioni_umid),
                    "dataeora": int(time.time()),
                    "invionumero": invio_numero,
                    "identita": config["IDENTITA_GIOT"]
                }

                # Criptazione e pubblicazione MQTT
                dato_criptato = cripta.criptazione(json.dumps(payload_da))
                client.publish(config["TOPIC"], dato_criptato)
                print(f"Pubblicato su topic '{config['TOPIC']}': {dato_criptato}")

                # Reset per prossima media
                rilevazioni_temp = []
                rilevazioni_umid = []
                invio_numero += 1
            else:
                print("Gateway IoT in attesa di dati")

    except KeyboardInterrupt:
        print(f"\nFine. Invii totali: {invio_numero - 1}")
        conn.close()
        client.loop_stop()
        client.disconnect()

if __name__ == "__main__":
    main()
